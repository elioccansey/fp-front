export type UserType = {
    name: string,
    email: string,
    password: string
    profileImage?: string
}